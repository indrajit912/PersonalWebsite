# PhD Thesis of Indrajit Ghosh

Welcome to the repository for my PhD thesis, completed at the Indian Statistical Institute, Bangalore, from 2019 to 2025.

## About

This repository contains the LaTeX source files for my PhD thesis. It includes all the necessary files to compile and generate the final document.

## PhD Advisor

My PhD advisor is **Dr. Soumyashant Nayak**.

## License

This repository is licensed under the **[Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)](https://creativecommons.org/licenses/by-nc/4.0/)** license. You are free to share, adapt, and use the contents of this repository for non-commercial purposes, as long as proper attribution is given.

## How to Compile

To compile the thesis, you need to have LaTeX installed. You can use any LaTeX editor (such as Overleaf, TeXShop, or TeXworks) or the command line.

### Steps to compile:

1. Clone or download the repository.
2. Open the `main.tex` file.
3. Compile the `main.tex` file using your preferred LaTeX editor or the following command:
```bash
pdflatex main.tex
bibtex main.tex
pdflatex main.tex
pdflatex main.tex
```

## Contact

If you have any questions or need further information, feel free to contact me at:
- Email: [Indrajit's Gmail](mailto:indrajitghosh912@gmail.com)